const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db/sheetsDb");
const { signToken, requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }
    const user = await db.getUserByEmail(email.toLowerCase().trim());
    if (!user) {
      return res.status(401).json({ error: "Incorrect email or password." });
    }
    const valid = bcrypt.compareSync(password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ error: "Incorrect email or password." });
    }
    const token = signToken({ id: user.id, role: user.role, name: user.name, email: user.email });
    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (err) {
    next(err);
  }
});

router.get("/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});

// Admin-only: create staff or admin accounts.
router.post("/users", requireAuth, requireRole("admin"), async (req, res, next) => {
  try {
    const { name, email, password, role } = req.body || {};
    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: "Name, email, password, and role are required." });
    }
    if (!["admin", "staff"].includes(role)) {
      return res.status(400).json({ error: "Role must be 'admin' or 'staff'." });
    }
    const hash = bcrypt.hashSync(password, 10);
    const user = await db.createUser({ name, email, passwordHash: hash, role });
    res.status(201).json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
});

router.get("/users", requireAuth, requireRole("admin"), async (req, res, next) => {
  try {
    const users = await db.getAllUsers();
    res.json({
      users: users
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
        .map((u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, createdAt: u.createdAt })),
    });
  } catch (err) {
    next(err);
  }
});

router.delete("/users/:id", requireAuth, requireRole("admin"), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (id === req.user.id) {
      return res.status(400).json({ error: "You can't delete your own account while logged in as it." });
    }
    await db.deleteUser(id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
