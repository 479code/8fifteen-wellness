const express = require("express");
const db = require("../db/sheetsDb");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

function serializeProduct(p, role) {
  const base = {
    id: p.id,
    name: p.name,
    category: p.category,
    sku: p.sku,
    price: p.price,
    stock: p.stock,
    reorderLevel: p.reorderLevel,
    updatedAt: p.updatedAt,
  };
  // Cost price (and therefore margin) is sensitive business data — only
  // admins see it. Staff get everything they need to sell and restock.
  if (role === "admin") {
    base.cost = p.cost;
  }
  return base;
}

router.get("/", requireAuth, async (req, res, next) => {
  try {
    const products = await db.getAllProducts();
    products.sort((a, b) => a.name.localeCompare(b.name));
    res.json({ products: products.map((p) => serializeProduct(p, req.user.role)) });
  } catch (err) {
    next(err);
  }
});

router.post("/", requireAuth, requireRole("admin"), async (req, res, next) => {
  try {
    const { name, category, sku, price, cost, stock, reorderLevel } = req.body || {};
    if (!name || !category || price == null) {
      return res.status(400).json({ error: "Name, category, and price are required." });
    }
    const product = await db.createProduct({ name, category, sku, price, cost, stock, reorderLevel });
    res.status(201).json({ product: serializeProduct(product, req.user.role) });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
});

router.patch("/:id", requireAuth, requireRole("admin"), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const fields = ["name", "category", "sku", "price", "cost", "reorderLevel"];
    const updates = {};
    for (const field of fields) {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    }
    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: "No valid fields to update." });
    }
    const updated = await db.updateProduct(id, updates);
    if (!updated) return res.status(404).json({ error: "Product not found." });
    res.json({ product: serializeProduct(updated, req.user.role) });
  } catch (err) {
    next(err);
  }
});

// Stock adjustment is allowed for staff too (restocking, corrections).
router.post("/:id/adjust-stock", requireAuth, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const { delta } = req.body || {};
    if (!Number.isInteger(delta)) {
      return res.status(400).json({ error: "delta must be an integer." });
    }
    const updated = await db.adjustProductStock(id, delta);
    if (!updated) return res.status(404).json({ error: "Product not found." });
    res.json({ product: serializeProduct(updated, req.user.role) });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", requireAuth, requireRole("admin"), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    await db.deleteProduct(id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
