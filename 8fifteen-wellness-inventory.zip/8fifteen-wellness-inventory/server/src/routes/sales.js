const express = require("express");
const db = require("../db/sheetsDb");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// Record a sale. Body: { customerName, items: [{ productId, qty }] }
router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { customerName, items } = req.body || {};
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "At least one item is required." });
    }
    const sale = await db.recordSale({ customerName, items, createdBy: req.user.id });
    res.status(201).json({ sale });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
});

router.get("/", requireAuth, async (req, res, next) => {
  try {
    const { from, to, limit } = req.query;
    const sales = await db.getSalesWithItems({ from, to, limit });
    res.json({ sales });
  } catch (err) {
    next(err);
  }
});

router.get("/stats/summary", requireAuth, async (req, res, next) => {
  try {
    const stats = await db.getStatsSummary();
    res.json(stats);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
