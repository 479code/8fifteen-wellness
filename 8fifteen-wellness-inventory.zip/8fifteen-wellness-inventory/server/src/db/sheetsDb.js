// Data access layer backed by Google Sheets. This is intentionally NOT a
// generic SQL-like interface — Sheets doesn't support transactions, joins,
// or indexes, so instead we expose the specific operations the app's
// routes actually need, each one written to be as safe as the underlying
// store allows.
//
// Important limitation to know about: Google Sheets has no row-level
// locking or transactions. If two requests try to write at almost exactly
// the same instant, it's possible (though unlikely for a single small
// shop) for one write to be overwritten by another. The sale recording
// logic below re-reads stock immediately before deducting it to minimize
// (not eliminate) this risk. If this ever becomes a real problem — e.g.
// multiple tills firing sales within the same second — that's the signal
// to migrate to a real database.

const client = require("./sheetsClient");

let idCounters = null; // lazily initialized cache of "next id" per tab

async function nextId(tabName, objects) {
  if (idCounters === null) idCounters = {};
  if (idCounters[tabName] === undefined) {
    const maxId = objects.reduce((max, o) => Math.max(max, Number(o.id) || 0), 0);
    idCounters[tabName] = maxId;
  }
  idCounters[tabName] += 1;
  return idCounters[tabName];
}

function nowIso() {
  return new Date().toISOString();
}

// ---------- Products ----------

async function getAllProducts() {
  const rows = await client.readTab(client.TABS.products);
  return client.rowsToObjects(rows).map(deserializeProduct);
}

function deserializeProduct(raw) {
  return {
    id: Number(raw.id),
    name: raw.name,
    category: raw.category,
    sku: raw.sku,
    price: Number(raw.price),
    cost: Number(raw.cost) || 0,
    stock: Number(raw.stock) || 0,
    reorderLevel: Number(raw.reorderLevel) || 0,
    createdAt: raw.createdAt,
    updatedAt: raw.updatedAt,
  };
}

function productToRow(p) {
  return [p.id, p.name, p.category, p.sku, p.price, p.cost, p.stock, p.reorderLevel, p.createdAt, p.updatedAt];
}

async function getProductById(id) {
  const all = await getAllProducts();
  return all.find((p) => p.id === Number(id)) || null;
}

async function createProduct({ name, category, sku, price, cost, stock, reorderLevel }) {
  const all = await getAllProducts();
  if (sku && all.some((p) => p.sku === sku)) {
    const err = new Error("A product with this SKU already exists.");
    err.status = 409;
    throw err;
  }
  const id = await nextId(client.TABS.products, all);
  const finalSku = sku && sku.trim() ? sku.trim() : `SKU-${Date.now().toString(36).toUpperCase()}`;
  const product = {
    id,
    name,
    category,
    sku: finalSku,
    price: Number(price),
    cost: Number(cost) || 0,
    stock: Number(stock) || 0,
    reorderLevel: Number(reorderLevel) || 5,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  };
  await client.appendRow(client.TABS.products, productToRow(product));
  return product;
}

// Finds the 1-indexed sheet row number for a product, accounting for the
// header row. Returns null if not found.
async function findProductRowNumber(id) {
  const rows = await client.readTab(client.TABS.products);
  for (let i = 1; i < rows.length; i++) {
    if (Number(rows[i][0]) === Number(id)) return i + 1; // +1 because sheet rows are 1-indexed
  }
  return null;
}

async function updateProduct(id, updates) {
  const rowNumber = await findProductRowNumber(id);
  if (!rowNumber) return null;
  const existing = await getProductById(id);
  const merged = { ...existing, ...updates, updatedAt: nowIso() };
  await client.updateRow(client.TABS.products, rowNumber, productToRow(merged));
  return merged;
}

// Adjusts stock by a delta (positive or negative), clamped at 0. Re-reads
// the current row immediately before writing to reduce (not eliminate)
// the chance of clobbering a concurrent update.
async function adjustProductStock(id, delta) {
  const rowNumber = await findProductRowNumber(id);
  if (!rowNumber) return null;
  const existing = await getProductById(id);
  if (!existing) return null;
  const newStock = Math.max(0, existing.stock + delta);
  const updated = { ...existing, stock: newStock, updatedAt: nowIso() };
  await client.updateRow(client.TABS.products, rowNumber, productToRow(updated));
  return updated;
}

async function deleteProduct(id) {
  const rowNumber = await findProductRowNumber(id);
  if (!rowNumber) return false;
  await client.deleteRow(client.TABS.products, rowNumber);
  return true;
}

// ---------- Users ----------

async function getAllUsers() {
  const rows = await client.readTab(client.TABS.users);
  return client.rowsToObjects(rows).map(deserializeUser);
}

function deserializeUser(raw) {
  return {
    id: Number(raw.id),
    name: raw.name,
    email: raw.email,
    passwordHash: raw.passwordHash,
    role: raw.role,
    createdAt: raw.createdAt,
  };
}

function userToRow(u) {
  return [u.id, u.name, u.email, u.passwordHash, u.role, u.createdAt];
}

async function getUserByEmail(email) {
  const all = await getAllUsers();
  return all.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
}

async function getUserById(id) {
  const all = await getAllUsers();
  return all.find((u) => u.id === Number(id)) || null;
}

async function createUser({ name, email, passwordHash, role }) {
  const all = await getAllUsers();
  const normalizedEmail = email.toLowerCase().trim();
  if (all.some((u) => u.email.toLowerCase() === normalizedEmail)) {
    const err = new Error("A user with this email already exists.");
    err.status = 409;
    throw err;
  }
  const id = await nextId(client.TABS.users, all);
  const user = { id, name, email: normalizedEmail, passwordHash, role, createdAt: nowIso() };
  await client.appendRow(client.TABS.users, userToRow(user));
  return user;
}

async function deleteUser(id) {
  const rows = await client.readTab(client.TABS.users);
  for (let i = 1; i < rows.length; i++) {
    if (Number(rows[i][0]) === Number(id)) {
      await client.deleteRow(client.TABS.users, i + 1);
      return true;
    }
  }
  return false;
}

// ---------- Sales & sale items ----------

async function getAllSales() {
  const rows = await client.readTab(client.TABS.sales);
  return client.rowsToObjects(rows).map(deserializeSale);
}

function deserializeSale(raw) {
  return {
    id: Number(raw.id),
    customerName: raw.customerName,
    total: Number(raw.total),
    createdBy: raw.createdBy ? Number(raw.createdBy) : null,
    createdAt: raw.createdAt,
  };
}

function saleToRow(s) {
  return [s.id, s.customerName, s.total, s.createdBy, s.createdAt];
}

async function getAllSaleItems() {
  const rows = await client.readTab(client.TABS.saleItems);
  return client.rowsToObjects(rows).map(deserializeSaleItem);
}

function deserializeSaleItem(raw) {
  return {
    id: Number(raw.id),
    saleId: Number(raw.saleId),
    productId: Number(raw.productId),
    productName: raw.productName,
    qty: Number(raw.qty),
    unitPrice: Number(raw.unitPrice),
  };
}

function saleItemToRow(i) {
  return [i.id, i.saleId, i.productId, i.productName, i.qty, i.unitPrice];
}

// Records a sale: validates stock for every line item against a single
// fresh read of the product list, deducts stock, and appends the sale +
// its line items. There is no multi-row transaction in Sheets, so we do
// all validation up front (against one consistent snapshot) before
// writing anything, to avoid partially-applied sales as much as possible.
async function recordSale({ customerName, items, createdBy }) {
  const products = await getAllProducts();
  const productMap = new Map(products.map((p) => [p.id, p]));

  let total = 0;
  const resolvedItems = [];
  for (const item of items) {
    const product = productMap.get(Number(item.productId));
    if (!product) {
      const err = new Error(`Product ${item.productId} not found.`);
      err.status = 404;
      throw err;
    }
    const qty = Number(item.qty);
    if (!Number.isInteger(qty) || qty <= 0) {
      const err = new Error(`Invalid quantity for ${product.name}.`);
      err.status = 400;
      throw err;
    }
    if (product.stock < qty) {
      const err = new Error(`Not enough stock for ${product.name}. Only ${product.stock} left.`);
      err.status = 409;
      throw err;
    }
    total += product.price * qty;
    resolvedItems.push({ product, qty });
  }

  const allSales = await getAllSales();
  const saleId = await nextId(client.TABS.sales, allSales);
  const sale = {
    id: saleId,
    customerName: (customerName || "Walk-in").trim() || "Walk-in",
    total,
    createdBy,
    createdAt: nowIso(),
  };
  await client.appendRow(client.TABS.sales, saleToRow(sale));

  const allSaleItems = await getAllSaleItems();
  let nextItemId = allSaleItems.reduce((max, o) => Math.max(max, o.id), 0);
  const itemRows = [];
  const savedItems = [];
  for (const { product, qty } of resolvedItems) {
    nextItemId += 1;
    const saleItem = {
      id: nextItemId,
      saleId,
      productId: product.id,
      productName: product.name,
      qty,
      unitPrice: product.price,
    };
    itemRows.push(saleItemToRow(saleItem));
    savedItems.push(saleItem);
  }
  await client.appendRows(client.TABS.saleItems, itemRows);

  // Deduct stock for each product. Done after recording the sale itself
  // so that, in the rare case a stock write fails partway through, the
  // sale record still exists and stock can be reconciled manually rather
  // than the sale silently vanishing.
  for (const { product, qty } of resolvedItems) {
    await adjustProductStock(product.id, -qty);
  }

  return { ...sale, items: savedItems.map((i) => ({ productId: i.productId, name: i.productName, qty: i.qty, unitPrice: i.unitPrice })) };
}

async function getSalesWithItems({ from, to, limit } = {}) {
  const [sales, saleItems] = await Promise.all([getAllSales(), getAllSaleItems()]);
  let filtered = sales;
  if (from) filtered = filtered.filter((s) => s.createdAt >= from);
  if (to) filtered = filtered.filter((s) => s.createdAt <= to);
  filtered = filtered.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  if (limit) filtered = filtered.slice(0, Number(limit));

  const itemsBySale = new Map();
  for (const item of saleItems) {
    if (!itemsBySale.has(item.saleId)) itemsBySale.set(item.saleId, []);
    itemsBySale.get(item.saleId).push({
      productId: item.productId,
      name: item.productName,
      qty: item.qty,
      unitPrice: item.unitPrice,
    });
  }

  return filtered.map((s) => ({
    id: s.id,
    customerName: s.customerName,
    total: s.total,
    createdAt: s.createdAt,
    items: itemsBySale.get(s.id) || [],
  }));
}

async function getStatsSummary() {
  const [products, sales, saleItems] = await Promise.all([getAllProducts(), getAllSales(), getAllSaleItems()]);

  const today = nowIso().slice(0, 10);
  const todaySales = sales.filter((s) => s.createdAt.slice(0, 10) === today);
  const todayRevenue = todaySales.reduce((sum, s) => sum + s.total, 0);
  const allTimeRevenue = sales.reduce((sum, s) => sum + s.total, 0);
  const totalUnitsSold = saleItems.reduce((sum, i) => sum + i.qty, 0);
  const inventoryValue = products.reduce((sum, p) => sum + p.price * p.stock, 0);
  const lowStock = products
    .filter((p) => p.stock <= p.reorderLevel)
    .sort((a, b) => a.stock - b.stock)
    .map((p) => ({ id: p.id, name: p.name, sku: p.sku, stock: p.stock, reorderLevel: p.reorderLevel }));

  const sellerCounts = new Map();
  for (const item of saleItems) {
    sellerCounts.set(item.productName, (sellerCounts.get(item.productName) || 0) + item.qty);
  }
  const topSellers = [...sellerCounts.entries()]
    .map(([name, qty]) => ({ name, qty }))
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  return {
    todayRevenue,
    todaySalesCount: todaySales.length,
    allTimeRevenue,
    totalUnitsSold,
    inventoryValue,
    productCount: products.length,
    lowStock,
    topSellers,
  };
}

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  adjustProductStock,
  deleteProduct,
  getAllUsers,
  getUserByEmail,
  getUserById,
  createUser,
  deleteUser,
  recordSale,
  getSalesWithItems,
  getStatsSummary,
};
