// Thin wrapper around the Google Sheets API. Everything here works in
// terms of raw rows of strings — the layer above (db.js) is responsible
// for turning those into real objects (numbers, etc.) and back.
const { google } = require("googleapis");
const path = require("path");
const fs = require("fs");

const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID;
if (!SPREADSHEET_ID) {
  throw new Error("GOOGLE_SHEET_ID environment variable is required.");
}

// Credentials can come from either a JSON file on disk (handy for local
// development — see GOOGLE_SERVICE_ACCOUNT_KEY_FILE in .env.example) or
// from the file's contents pasted directly into an environment variable
// (the standard pattern on hosts like Render/Vercel, where you can't
// commit a secret file to git but can set a secret env var). If both are
// set, the inline JSON value takes priority.
let credentials;
if (process.env.GOOGLE_SERVICE_ACCOUNT_KEY_JSON) {
  try {
    credentials = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY_JSON);
  } catch (e) {
    throw new Error(
      "GOOGLE_SERVICE_ACCOUNT_KEY_JSON is set but is not valid JSON. " +
        "Paste the entire contents of the downloaded service account .json file as-is."
    );
  }
} else if (process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE) {
  const keyFile = path.resolve(process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE);
  if (!fs.existsSync(keyFile)) {
    throw new Error(
      `GOOGLE_SERVICE_ACCOUNT_KEY_FILE not found at "${keyFile}". ` +
        "Download the service account JSON key from Google Cloud and point this env var at it."
    );
  }
  credentials = JSON.parse(fs.readFileSync(keyFile, "utf8"));
} else {
  throw new Error(
    "Set either GOOGLE_SERVICE_ACCOUNT_KEY_FILE (path to the downloaded JSON key, for local dev) " +
      "or GOOGLE_SERVICE_ACCOUNT_KEY_JSON (the file's contents pasted directly, for hosted deployments)."
  );
}

const auth = new google.auth.GoogleAuth({
  credentials,
  scopes: ["https://www.googleapis.com/auth/spreadsheets"],
});

const sheetsPromise = google.sheets({ version: "v4", auth });

// Tab names exactly as they exist in the spreadsheet. Sheets tab names are
// case-sensitive in the API, so these must match the actual tab labels.
const TABS = {
  products: "Products",
  sales: "sales",
  saleItems: "saleItems",
  users: "Users",
};

// Reads all rows from a tab (including the header row) as arrays of strings.
async function readTab(tabName) {
  const sheets = await sheetsPromise;
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: SPREADSHEET_ID,
    range: `${tabName}!A:Z`,
  });
  return res.data.values || [];
}

// Converts raw rows (first row = headers) into an array of plain objects.
function rowsToObjects(rows) {
  if (rows.length === 0) return [];
  const [headers, ...dataRows] = rows;
  return dataRows
    .filter((row) => row.some((cell) => cell !== undefined && cell !== ""))
    .map((row) => {
      const obj = {};
      headers.forEach((header, i) => {
        obj[header] = row[i] !== undefined ? row[i] : "";
      });
      return obj;
    });
}

// Appends a single row (array of values, in column order matching the
// sheet's header row) to the end of a tab.
async function appendRow(tabName, rowValues) {
  const sheets = await sheetsPromise;
  await sheets.spreadsheets.values.append({
    spreadsheetId: SPREADSHEET_ID,
    range: `${tabName}!A:Z`,
    valueInputOption: "RAW",
    insertDataOption: "INSERT_ROWS",
    requestBody: { values: [rowValues] },
  });
}

// Appends multiple rows at once (one API call instead of N — important
// because Sheets has a rate limit on requests per minute).
async function appendRows(tabName, rowsOfValues) {
  if (rowsOfValues.length === 0) return;
  const sheets = await sheetsPromise;
  await sheets.spreadsheets.values.append({
    spreadsheetId: SPREADSHEET_ID,
    range: `${tabName}!A:Z`,
    valueInputOption: "RAW",
    insertDataOption: "INSERT_ROWS",
    requestBody: { values: rowsOfValues },
  });
}

// Overwrites one specific row (1-indexed, including the header as row 1)
// with new values. Used for updates (e.g. adjusting stock).
async function updateRow(tabName, rowNumber, rowValues) {
  const sheets = await sheetsPromise;
  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range: `${tabName}!A${rowNumber}:Z${rowNumber}`,
    valueInputOption: "RAW",
    requestBody: { values: [rowValues] },
  });
}

// Deletes a row by its 1-indexed sheet row number. Requires the tab's
// internal numeric sheetId (different from the spreadsheet ID), which we
// look up via the spreadsheet metadata.
const sheetIdCache = {};
async function getTabSheetId(tabName) {
  if (sheetIdCache[tabName] !== undefined) return sheetIdCache[tabName];
  const sheets = await sheetsPromise;
  const meta = await sheets.spreadsheets.get({ spreadsheetId: SPREADSHEET_ID });
  const tab = meta.data.sheets.find((s) => s.properties.title === tabName);
  if (!tab) throw new Error(`Tab "${tabName}" not found in spreadsheet.`);
  sheetIdCache[tabName] = tab.properties.sheetId;
  return tab.properties.sheetId;
}

async function deleteRow(tabName, rowNumber) {
  const sheets = await sheetsPromise;
  const sheetId = await getTabSheetId(tabName);
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SPREADSHEET_ID,
    requestBody: {
      requests: [
        {
          deleteDimension: {
            range: {
              sheetId,
              dimension: "ROWS",
              startIndex: rowNumber - 1,
              endIndex: rowNumber,
            },
          },
        },
      ],
    },
  });
}

module.exports = { TABS, readTab, rowsToObjects, appendRow, appendRows, updateRow, deleteRow };
