// Seeds the spreadsheet with an initial admin user and sample products.
// Safe to run multiple times — it skips creating the admin if a user with
// that email already exists, and skips products whose SKU already exists.
require("dotenv").config();
const bcrypt = require("bcryptjs");
const db = require("./sheetsDb");

const ADMIN_EMAIL = process.env.SEED_ADMIN_EMAIL || "admin@8fifteenwellness.com";
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD || "ChangeMe123!";
const ADMIN_NAME = process.env.SEED_ADMIN_NAME || "8fifteen Wellness Admin";

async function seedAdmin() {
  const existing = await db.getUserByEmail(ADMIN_EMAIL);
  if (existing) {
    console.log(`Admin user already exists (${ADMIN_EMAIL}), skipping.`);
    return;
  }
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 10);
  await db.createUser({ name: ADMIN_NAME, email: ADMIN_EMAIL, passwordHash: hash, role: "admin" });
  console.log(`Created admin user: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  console.log("IMPORTANT: log in and change this password, or set SEED_ADMIN_PASSWORD before seeding in production.");
}

const SEED_PRODUCTS = [
  // Beauty & Cosmetics
  { name: "Matte Liquid Lipstick", category: "Beauty & Cosmetics", price: 3500, cost: 1800, stock: 22, reorderLevel: 8, sku: "BC-LL01" },
  { name: "Full Coverage Foundation 30ml", category: "Beauty & Cosmetics", price: 7200, cost: 4100, stock: 14, reorderLevel: 5, sku: "BC-FD02" },
  { name: "Eyeshadow Palette (12 Shades)", category: "Beauty & Cosmetics", price: 9500, cost: 5600, stock: 9, reorderLevel: 4, sku: "BC-EP03" },
  { name: "Waterproof Mascara", category: "Beauty & Cosmetics", price: 4200, cost: 2200, stock: 18, reorderLevel: 6, sku: "BC-MS04" },
  { name: "Makeup Setting Spray", category: "Beauty & Cosmetics", price: 5800, cost: 3100, stock: 11, reorderLevel: 5, sku: "BC-SS05" },

  // Personal Care
  { name: "Shea Butter Body Lotion 400ml", category: "Personal Care", price: 4500, cost: 2400, stock: 26, reorderLevel: 10, sku: "PC-BL01" },
  { name: "Charcoal Face Wash 150ml", category: "Personal Care", price: 3200, cost: 1600, stock: 20, reorderLevel: 8, sku: "PC-FW02" },
  { name: "Electric Toothbrush", category: "Personal Care", price: 12500, cost: 7800, stock: 7, reorderLevel: 3, sku: "PC-ET03" },
  { name: "Roll-On Deodorant", category: "Personal Care", price: 1800, cost: 900, stock: 34, reorderLevel: 12, sku: "PC-RD04" },
  { name: "Hair Growth Oil 100ml", category: "Personal Care", price: 4800, cost: 2500, stock: 15, reorderLevel: 6, sku: "PC-HO05" },

  // Tea
  { name: "Green Tea Bags (Box of 25)", category: "Tea", price: 2800, cost: 1500, stock: 30, reorderLevel: 10, sku: "TE-GT01" },
  { name: "Chamomile Herbal Tea (Box of 20)", category: "Tea", price: 3100, cost: 1650, stock: 24, reorderLevel: 8, sku: "TE-CH02" },
  { name: "Ginger & Lemon Tea (Box of 20)", category: "Tea", price: 2900, cost: 1500, stock: 19, reorderLevel: 8, sku: "TE-GL03" },
  { name: "Detox Slimming Tea (Box of 14)", category: "Tea", price: 4200, cost: 2300, stock: 12, reorderLevel: 5, sku: "TE-DT04" },
  { name: "Loose Leaf Earl Grey 100g", category: "Tea", price: 5200, cost: 2900, stock: 8, reorderLevel: 4, sku: "TE-EG05" },

  // Shopping / General Retail
  { name: "Reusable Tote Bag", category: "General Retail", price: 1500, cost: 700, stock: 40, reorderLevel: 15, sku: "GR-TB01" },
  { name: "Insulated Water Bottle 750ml", category: "General Retail", price: 6500, cost: 3600, stock: 16, reorderLevel: 6, sku: "GR-WB02" },
  { name: "Scented Candle (Lavender)", category: "General Retail", price: 3800, cost: 2000, stock: 21, reorderLevel: 8, sku: "GR-SC03" },
  { name: "Gift Wrapping Set", category: "General Retail", price: 2200, cost: 1100, stock: 17, reorderLevel: 6, sku: "GR-GW04" },
  { name: "Travel Toiletry Bag", category: "General Retail", price: 4000, cost: 2100, stock: 13, reorderLevel: 5, sku: "GR-TT05" },
];

async function seedProducts() {
  const existing = await db.getAllProducts();
  const existingSkus = new Set(existing.map((p) => p.sku));
  let created = 0;
  for (const product of SEED_PRODUCTS) {
    if (existingSkus.has(product.sku)) continue;
    await db.createProduct(product);
    created++;
  }
  console.log(`Seeded ${created} new product(s) (${SEED_PRODUCTS.length - created} already existed and were skipped).`);
}

async function main() {
  await seedAdmin();
  await seedProducts();
  console.log("Seed complete.");
}

main().catch((err) => {
  console.error("Seeding failed:", err.message);
  process.exit(1);
});
