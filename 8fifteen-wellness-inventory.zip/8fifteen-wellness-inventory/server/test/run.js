// Integration test for the 8fifteen Wellness Inventory API, backed by an
// in-memory fake of the Google Sheets client (test/fakeSheetsClient.js) so
// this runs with no real Google credentials or network access. Run with:
//   node test/run.js

process.env.JWT_SECRET = "test-secret";
process.env.NODE_ENV = "test";
process.env.GOOGLE_SHEET_ID = "fake-sheet-id-for-tests";
process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE = "/dev/null"; // unused, sheetsClient is swapped out below

const path = require("path");
const Module = require("module");
const fakeClient = require("./fakeSheetsClient");

// Redirect any `require("./sheetsClient")` (relative, from inside src/db/)
// to our in-memory fake instead of the real Google API wrapper.
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
  if (request === "./sheetsClient") {
    return path.join(__dirname, "fakeSheetsClient.js");
  }
  return originalResolve.call(this, request, ...rest);
};

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");

const authRoutes = require("../src/routes/auth");
const productRoutes = require("../src/routes/products");
const salesRoutes = require("../src/routes/sales");
const db = require("../src/db/sheetsDb");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/sales", salesRoutes);
app.use((err, req, res, next) => {
  res.status(err.status || 500).json({ error: err.message || "Something went wrong." });
});

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    passed++;
    console.log(`  ok - ${message}`);
  } else {
    failed++;
    console.log(`  FAIL - ${message}`);
  }
}

async function request(server, method, urlPath, body, token) {
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  const res = await fetch(baseUrl + urlPath, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  let json = null;
  try {
    json = await res.json();
  } catch (e) {
    json = null;
  }
  return { status: res.status, body: json };
}

async function main() {
  fakeClient.__reset();

  const adminHash = bcrypt.hashSync("AdminPass123!", 10);
  await db.createUser({ name: "Test Admin", email: "admin@test.com", passwordHash: adminHash, role: "admin" });
  const staffHash = bcrypt.hashSync("StaffPass123!", 10);
  await db.createUser({ name: "Test Staff", email: "staff@test.com", passwordHash: staffHash, role: "staff" });

  const server = app.listen(0);
  await new Promise((resolve) => server.once("listening", resolve));

  console.log("\n--- Auth ---");
  let res = await request(server, "POST", "/api/auth/login", { email: "admin@test.com", password: "AdminPass123!" });
  assert(res.status === 200, "admin can log in with correct password");
  const adminToken = res.body.token;
  assert(!!adminToken, "login returns a token");
  assert(res.body.user.role === "admin", "logged in user has admin role");

  res = await request(server, "POST", "/api/auth/login", { email: "admin@test.com", password: "WrongPassword" });
  assert(res.status === 401, "login fails with wrong password");

  res = await request(server, "POST", "/api/auth/login", { email: "staff@test.com", password: "StaffPass123!" });
  const staffToken = res.body.token;
  assert(res.status === 200 && !!staffToken, "staff can log in");

  res = await request(server, "GET", "/api/products", null, null);
  assert(res.status === 401, "products endpoint rejects requests with no token");

  console.log("\n--- Products & roles ---");
  res = await request(server, "POST", "/api/products", {
    name: "Vitamin C Serum 30ml",
    category: "Beauty & Cosmetics",
    price: 12000,
    cost: 7000,
    stock: 10,
    reorderLevel: 3,
  }, adminToken);
  assert(res.status === 201, "admin can create a product");
  const productId = res.body.product.id;
  assert(res.body.product.cost === 7000, "admin sees cost price in response");

  res = await request(server, "POST", "/api/products", {
    name: "Should not be created",
    category: "Beauty & Cosmetics",
    price: 1000,
  }, staffToken);
  assert(res.status === 403, "staff cannot create a product");

  res = await request(server, "GET", "/api/products", null, staffToken);
  const staffProduct = res.body.products.find((p) => p.id === productId);
  assert(staffProduct.cost === undefined, "staff does not see cost price");
  assert(staffProduct.price === 12000, "staff sees selling price");

  console.log("\n--- Sales flow ---");
  res = await request(server, "POST", "/api/sales", {
    customerName: "Mrs. Adeyemi",
    items: [{ productId, qty: 3 }],
  }, staffToken);
  assert(res.status === 201, "staff can record a sale");
  assert(res.body.sale.total === 36000, "sale total is computed correctly (3 x 12000)");

  res = await request(server, "GET", "/api/products", null, adminToken);
  let afterSale = res.body.products.find((p) => p.id === productId);
  assert(afterSale.stock === 7, "stock decremented correctly after sale (10 - 3 = 7)");

  res = await request(server, "POST", "/api/sales", {
    customerName: "Overselling test",
    items: [{ productId, qty: 999 }],
  }, staffToken);
  assert(res.status === 409, "selling more than available stock is rejected");

  res = await request(server, "GET", "/api/products", null, adminToken);
  const afterFailedSale = res.body.products.find((p) => p.id === productId);
  assert(afterFailedSale.stock === 7, "stock unchanged after a rejected oversell");

  console.log("\n--- Stock adjustment ---");
  res = await request(server, "POST", `/api/products/${productId}/adjust-stock`, { delta: 5 }, staffToken);
  assert(res.status === 200 && res.body.product.stock === 12, "staff can adjust stock up (restock), 7 + 5 = 12");

  console.log("\n--- Dashboard stats ---");
  res = await request(server, "GET", "/api/sales/stats/summary", null, adminToken);
  assert(res.status === 200, "stats summary endpoint responds");
  assert(res.body.allTimeRevenue === 36000, "all-time revenue matches recorded sale");
  assert(res.body.totalUnitsSold === 3, "total units sold matches recorded sale");
  assert(Array.isArray(res.body.topSellers) && res.body.topSellers[0].name === "Vitamin C Serum 30ml", "top sellers includes the sold product");

  console.log("\n--- User management (admin only) ---");
  res = await request(server, "POST", "/api/auth/users", { name: "New Staff", email: "new@test.com", password: "Pass123!", role: "staff" }, staffToken);
  assert(res.status === 403, "staff cannot create new users");

  res = await request(server, "POST", "/api/auth/users", { name: "New Staff", email: "new@test.com", password: "Pass123!", role: "staff" }, adminToken);
  assert(res.status === 201, "admin can create new staff user");

  console.log("\n--- Multiple sales & sales history ---");
  await request(server, "POST", "/api/sales", { customerName: "Walk-in", items: [{ productId, qty: 2 }] }, staffToken);
  res = await request(server, "GET", "/api/sales", null, adminToken);
  assert(res.status === 200 && res.body.sales.length === 2, "sales history returns both recorded sales");
  assert(res.body.sales[0].items.length > 0, "each sale includes its line items");

  console.log("\n--- Product deletion ---");
  res = await request(server, "DELETE", `/api/products/${productId}`, null, staffToken);
  assert(res.status === 403, "staff cannot delete a product");
  res = await request(server, "DELETE", `/api/products/${productId}`, null, adminToken);
  assert(res.status === 200, "admin can delete a product");
  res = await request(server, "GET", "/api/products", null, adminToken);
  assert(!res.body.products.some((p) => p.id === productId), "deleted product no longer appears in product list");

  server.close();

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Test run crashed:", err);
  process.exit(1);
});
