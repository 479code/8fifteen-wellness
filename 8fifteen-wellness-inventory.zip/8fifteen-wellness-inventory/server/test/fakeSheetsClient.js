// In-memory fake of sheetsClient.js, used only for automated tests so we
// don't need real Google credentials or network access to verify the
// route/business logic. Mimics the same tab structure and row-based API.

const TABS = {
  products: "Products",
  sales: "sales",
  saleItems: "saleItems",
  users: "Users",
};

const HEADERS = {
  [TABS.products]: ["id", "name", "category", "sku", "price", "cost", "stock", "reorderLevel", "createdAt", "updatedAt"],
  [TABS.sales]: ["id", "customerName", "total", "createdBy", "createdAt"],
  [TABS.saleItems]: ["id", "saleId", "productId", "productName", "qty", "unitPrice"],
  [TABS.users]: ["id", "name", "email", "passwordHash", "role", "createdAt"],
};

let store = null;

function reset() {
  store = {
    [TABS.products]: [HEADERS[TABS.products]],
    [TABS.sales]: [HEADERS[TABS.sales]],
    [TABS.saleItems]: [HEADERS[TABS.saleItems]],
    [TABS.users]: [HEADERS[TABS.users]],
  };
}
reset();

async function readTab(tabName) {
  // Return a deep-ish copy so callers can't mutate our internal state directly.
  return store[tabName].map((row) => [...row]);
}

function rowsToObjects(rows) {
  if (rows.length === 0) return [];
  const [headers, ...dataRows] = rows;
  return dataRows
    .filter((row) => row.some((cell) => cell !== undefined && cell !== ""))
    .map((row) => {
      const obj = {};
      headers.forEach((header, i) => {
        obj[header] = row[i] !== undefined ? row[i] : "";
      });
      return obj;
    });
}

async function appendRow(tabName, rowValues) {
  store[tabName].push(rowValues.map((v) => (v === undefined || v === null ? "" : v)));
}

async function appendRows(tabName, rowsOfValues) {
  for (const row of rowsOfValues) {
    await appendRow(tabName, row);
  }
}

async function updateRow(tabName, rowNumber, rowValues) {
  // rowNumber is 1-indexed including the header row, matching the real client.
  store[tabName][rowNumber - 1] = rowValues.map((v) => (v === undefined || v === null ? "" : v));
}

async function deleteRow(tabName, rowNumber) {
  store[tabName].splice(rowNumber - 1, 1);
}

module.exports = { TABS, readTab, rowsToObjects, appendRow, appendRows, updateRow, deleteRow, __reset: reset };
