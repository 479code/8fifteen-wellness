# 8fifteen Wellness — Smart Inventory & Sales

A full-stack inventory and point-of-sale system for a beauty, personal care,
and tea retail shop: product catalog, stock tracking with low-stock alerts, a
till-style sale flow that deducts stock automatically, sales history, a
dashboard, and staff accounts with admin/staff roles.

```
8fifteen-wellness-inventory/
├── server/     Express API (auth, products, sales) — data lives in a Google Sheet
├── client/     React + Vite frontend
└── render.yaml Deployment blueprint for Render
```

## How it works

- **Backend**: Node.js + Express, JWT auth, bcrypt password hashing. Two
  roles: `admin` (full access, including cost prices, staff management,
  deleting products) and `staff` (record sales, view inventory and selling
  prices, adjust stock, can't see cost/margin or manage other users).
- **Frontend**: React (Vite), calls the backend over a REST API, stores the
  JWT in `localStorage`.
- **Database**: a Google Sheet. Each tab is a table — `Products`, `sales`,
  `saleItems`, `Users`. The backend authenticates as a Google "service
  account" (a robot identity, not a personal login) that you share the
  sheet with as an Editor. No database server to install, no native code
  to compile — you can also just open the spreadsheet directly to glance
  at your data.

### Why Sheets, and when to outgrow it

This is a deliberately simple, zero-setup-friction data store, well suited
to one shop with one or two people using the app at a time. Worth knowing
about going in:

- Every read and write is a network call to Google, so it's slower than a
  real database — noticeable on slow connections, not a problem for normal
  single-till use.
- Sheets has no real transactions or row locking. The sale-recording logic
  re-reads stock immediately before deducting it to minimize (not
  eliminate) the chance of two near-simultaneous sales clobbering each
  other's stock update. For one shop, one till, this is very unlikely to
  bite you in practice.
- Google enforces API rate limits (generous for this scale, but worth
  knowing about if usage grows a lot).

If the shop grows — more tills, more staff hitting it at once, or you just
want stronger data guarantees — the natural next step is migrating to a
real database (Postgres is the common choice). The app's route files don't
talk to Sheets directly; they call functions in `server/src/db/sheetsDb.js`
(`getAllProducts`, `recordSale`, etc.). Migrating later means rewriting the
*inside* of those functions to use a real database client instead of the
Sheets API — the routes and the frontend don't need to change. Ask any
time and I can do that swap.

---

## 1. One-time Google Cloud & Sheets setup

You need three things before the backend will run: the Sheets API enabled
on a Google Cloud project, a service account with a downloaded JSON key,
and a Google Sheet shared with that service account as an Editor.

1. Go to [console.cloud.google.com](https://console.cloud.google.com/),
   pick or create a project.
2. Search for **Google Sheets API** in the top search bar and click
   **Enable**.
3. Go to **APIs & Services → Credentials → Create Credentials → Service
   account**. Give it any name (e.g. `8fifteen-inventory-app`). Skip the
   optional role and user-access steps.
4. Open the new service account → **Keys** tab → **Add key → Create new
   key → JSON**. This downloads a `.json` file — keep it private, like a
   password.
5. Create a new Google Sheet. Add four tabs with these exact names and
   header rows (row 1):

   | Tab name    | Headers (row 1, one per column, in order) |
   |-------------|----------------------------------------------------------------------------|
   | `Products`  | `id, name, category, sku, price, cost, stock, reorderLevel, createdAt, updatedAt` |
   | `sales`     | `id, customerName, total, createdBy, createdAt` |
   | `saleItems` | `id, saleId, productId, productName, qty, unitPrice` |
   | `Users`     | `id, name, email, passwordHash, role, createdAt` |

6. Click **Share** on the spreadsheet, paste in the service account's email
   address (looks like `xxx@your-project.iam.gserviceaccount.com` — find it
   on the service account's **Details** tab), set its role to **Editor**,
   and share.
7. Copy the Sheet ID out of the spreadsheet's URL — the long string between
   `/d/` and `/edit`:
   ```
   https://docs.google.com/spreadsheets/d/THIS_PART_HERE/edit
   ```

You'll use the Sheet ID and the downloaded JSON key file in the next step.

---

## 2. Run it locally

You'll need [Node.js](https://nodejs.org) 18 or newer.

### Backend

```bash
cd server
cp .env.example .env
```

Open `.env` in a text editor and fill in:

- `GOOGLE_SHEET_ID` — the Sheet ID from step 1.7 above.
- `GOOGLE_SERVICE_ACCOUNT_KEY_FILE` — path to the downloaded JSON key file.
  The simplest approach: create a `server/credentials/` folder, put the
  key file there, and set this to `./credentials/service-account.json`
  (that folder is already in `.gitignore`, so the key never gets
  accidentally committed to git).

Then:

```bash
npm install
npm run seed     # creates the admin account and sample products in your Sheet
npm start
```

The seed script prints the admin login it created (defaults to
`admin@8fifteenwellness.com` / `ChangeMe123!` unless you set
`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` in `.env` first). The API runs on
`http://localhost:4000`.

**Change that default password as your first action after logging in for
real use** — there's no in-app "change password" screen yet, so for now
that means either re-running the seed with a new `SEED_ADMIN_PASSWORD`
(after removing the old admin row from the `Users` tab), or asking me to
add a proper change-password screen.

### Frontend

In a separate terminal:

```bash
cd client
cp .env.example .env   # VITE_API_URL=http://localhost:4000
npm install
npm run dev
```

Open `http://localhost:5173` and log in with the admin account from the
seed step.

---

## 3. Deploy it live

Because the data lives in Google Sheets rather than a local file, the
backend has no persistent-disk requirement — any standard Node host works,
including ones with ephemeral filesystems. Render is still a solid choice
since the included blueprint targets it directly, but you're no longer
locked out of Vercel/Railway/Fly.io etc. the way SQLite would have forced.

### Option A — Render, using the included blueprint

1. Push this project to a GitHub repository (the `credentials/` folder and
   `.env` files are gitignored and won't be pushed — good, they shouldn't
   be).
2. In the Render dashboard, choose **New > Blueprint**, point it at your
   repo. Render reads `render.yaml` and sets up two services:
   `8fifteen-wellness-api` (backend) and `8fifteen-wellness-app` (frontend).
3. Render will prompt you to fill in a few secret values it can't read from
   the blueprint file:
   - `GOOGLE_SHEET_ID` — your Sheet ID.
   - `GOOGLE_SERVICE_ACCOUNT_KEY_JSON` — open the downloaded JSON key file
     in a text editor, select all, copy, and paste the **entire contents**
     into this field. (This is different from local dev, which points at a
     file path — hosted platforms can't read a file from your laptop, so
     here we paste the file's contents directly into an environment
     variable instead.)
   - `SEED_ADMIN_PASSWORD` — pick a real password.
   `JWT_SECRET` is auto-generated for you.
4. After the first deploy, open a shell on the `8fifteen-wellness-api`
   service (Render dashboard → service → **Shell**) and run:
   ```bash
   npm run seed
   ```
5. Update `CORS_ORIGIN` (on the API service) and `VITE_API_URL` (on the
   frontend service) to match the real `.onrender.com` URLs Render assigns
   after the first deploy, then redeploy both.

### Option B — Manual setup on Render (no blueprint)

1. **Backend**: New → Web Service → connect repo → root directory `server`
   → build command `npm install` → start command `npm start`. Set env
   vars: `NODE_ENV=production`, `JWT_SECRET=<random string>`,
   `CORS_ORIGIN=<your frontend URL>`, `GOOGLE_SHEET_ID=<your sheet id>`,
   `GOOGLE_SERVICE_ACCOUNT_KEY_JSON=<paste the full json key file contents>`.
   After first deploy, open the shell and run `npm run seed`.
2. **Frontend**: New → Static Site → root directory `client` → build
   command `npm install && npm run build` → publish directory `dist`. Set
   `VITE_API_URL=<your backend URL>`. Add a rewrite rule `/*` →
   `/index.html` so client-side routing survives a page refresh.

### Other hosts

Any host that runs a long-lived Node process (Railway, Fly.io, a VPS) or
even most serverless platforms works the same way, since there's no file
storage dependency anymore — set the same environment variables described
above.

---

## 4. Project structure reference

```
server/
  src/
    db/
      sheetsClient.js   Low-level Google Sheets API wrapper (raw rows in/out)
      sheetsDb.js        Data access layer: getAllProducts, recordSale, etc.
      seed.js             Creates the first admin account + sample products
    middleware/
      auth.js             JWT signing/verification, role-checking middleware
    routes/
      auth.js              Login, current user, staff account management
      products.js          Product CRUD, stock adjustment
      sales.js             Recording sales, history, dashboard stats
    index.js               Express app entry point
  test/
    fakeSheetsClient.js    In-memory fake of the Sheets API, for testing
    run.js                  Integration tests (auth, roles, sales, stock)

client/
  src/
    lib/
      api.js               Fetch wrapper, attaches JWT, handles 401s
      AuthContext.jsx       React context for the logged-in user
      styleTokens.js        Shared design tokens/styles
    components/
      Layout.jsx            Header + nav, wraps authenticated pages
      Shared.jsx             EmptyState, Toast, SectionTitle, hooks
    pages/
      Login.jsx, Dashboard.jsx, Inventory.jsx, RecordSale.jsx,
      SalesHistory.jsx, Staff.jsx
    App.jsx                Routing + auth guards
```

### A note on `server/test/`

The automated tests run against `test/fakeSheetsClient.js`, an in-memory
stand-in for the real Google Sheets API, so they run instantly with no
network calls and no risk of writing test data into your real spreadsheet.
Production code never imports this fake — it's wired in only inside
`test/run.js`. Run `node test/run.js` after making backend changes to
re-verify auth, role checks, the sale flow, and stock deduction still work.

---

## 5. Roles, at a glance

| Action                         | Admin | Staff |
|---------------------------------|:---:|:---:|
| View inventory & selling prices | ✅ | ✅ |
| View cost price / margins       | ✅ | ❌ |
| Add / edit / delete products    | ✅ | ❌ |
| Adjust stock (restock/correct)  | ✅ | ✅ |
| Record a sale                   | ✅ | ✅ |
| View sales history & dashboard  | ✅ | ✅ |
| Manage staff accounts           | ✅ | ❌ |

## 6. Things you may want next

- A "change my password" screen.
- Migrating from Google Sheets to a real database once usage grows (see
  the note in "Why Sheets, and when to outgrow it" above).
- Receipt printing or PDF export for completed sales.
- CSV export of inventory or sales history.

Ask any time — these are all reasonably small additions on top of this
foundation.
