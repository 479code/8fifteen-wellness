import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/AuthContext";
import { api } from "./lib/api";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Inventory from "./pages/Inventory";
import RecordSale from "./pages/RecordSale";
import SalesHistory from "./pages/SalesHistory";
import Staff from "./pages/Staff";
import { styles } from "./lib/styleTokens";

function RequireAuth({ children }) {
  const { user, checking } = useAuth();
  const location = useLocation();
  if (checking) return <div style={styles.pageLoader}>Loading…</div>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  return children;
}

function RequireAdmin({ children }) {
  const { isAdmin } = useAuth();
  if (!isAdmin) return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  const [lowStockCount, setLowStockCount] = useState(0);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;
    api.getStats().then((data) => setLowStockCount(data.lowStock.length)).catch(() => {});
  }, [user]);

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <RequireAuth>
            <Layout lowStockCount={lowStockCount} />
          </RequireAuth>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="inventory" element={<Inventory />} />
        <Route path="sale" element={<RecordSale />} />
        <Route path="history" element={<SalesHistory />} />
        <Route
          path="staff"
          element={
            <RequireAdmin>
              <Staff />
            </RequireAdmin>
          }
        />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
