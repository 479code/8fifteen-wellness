import React from "react";
import { styles } from "../lib/styleTokens";

export function SectionTitle({ eyebrow, title, action }) {
  return (
    <div style={styles.sectionTitleWrap}>
      <div>
        <div style={styles.eyebrow}>{eyebrow}</div>
        <h1 style={styles.sectionTitle}>{title}</h1>
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ text }) {
  return <div style={styles.emptyState}>{text}</div>;
}

export function Toast({ toast }) {
  if (!toast) return null;
  return <div style={styles.toast}>{toast.msg}</div>;
}

export function useToast() {
  const [toast, setToast] = React.useState(null);
  const showToast = React.useCallback((msg) => {
    setToast({ msg, id: Math.random() });
  }, []);
  React.useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2600);
    return () => clearTimeout(t);
  }, [toast]);
  return { toast, showToast };
}

export function useIsNarrow(breakpoint = 760) {
  const [isNarrow, setIsNarrow] = React.useState(
    typeof window !== "undefined" ? window.innerWidth < breakpoint : false
  );
  React.useEffect(() => {
    const handler = () => setIsNarrow(window.innerWidth < breakpoint);
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, [breakpoint]);
  return isNarrow;
}
