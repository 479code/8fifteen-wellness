import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { LayoutDashboard, Package, Receipt, TrendingUp, Users } from "lucide-react";
import { useAuth } from "../lib/AuthContext";
import { styles, globalCss } from "../lib/styleTokens";

export default function Layout({ lowStockCount = 0 }) {
  const { user, logout, isAdmin } = useAuth();

  const navItems = [
    { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
    { to: "/inventory", label: "Inventory", icon: Package },
    { to: "/sale", label: "Record Sale", icon: Receipt },
    { to: "/history", label: "Sales History", icon: TrendingUp },
    ...(isAdmin ? [{ to: "/staff", label: "Staff", icon: Users }] : []),
  ];

  return (
    <div style={styles.app}>
      <style>{globalCss}</style>
      <header style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.brand}>
            <div style={styles.brandMark}>8F</div>
            <div>
              <div style={styles.brandName}>8fifteen Wellness</div>
              <div style={styles.brandSub}>Beauty, Care &amp; Tea — Stock Desk</div>
            </div>
          </div>
          <nav style={styles.nav}>
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  style={({ isActive }) => ({ ...styles.navBtn, ...(isActive ? styles.navBtnActive : {}) })}
                >
                  <Icon size={16} strokeWidth={2.2} />
                  <span>{item.label}</span>
                  {item.to === "/inventory" && lowStockCount > 0 && (
                    <span style={styles.navBadge}>{lowStockCount}</span>
                  )}
                </NavLink>
              );
            })}
            <div style={styles.userChip}>
              <span>{user?.name} · {user?.role}</span>
              <button style={styles.logoutBtn} onClick={logout}>Sign out</button>
            </div>
          </nav>
        </div>
      </header>
      <main style={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}
