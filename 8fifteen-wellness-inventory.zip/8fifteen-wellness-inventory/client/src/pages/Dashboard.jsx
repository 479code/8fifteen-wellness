import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle } from "lucide-react";
import { api } from "../lib/api";
import { styles, currency, ACCENTS } from "../lib/styleTokens";
import { SectionTitle, EmptyState, useIsNarrow } from "../components/Shared";

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const isNarrow = useIsNarrow();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await api.getStats();
        if (!cancelled) setStats(data);
      } catch (err) {
        if (!cancelled) setError(err.message || "Could not load dashboard.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) return <div style={styles.emptyState}>Loading dashboard…</div>;
  if (error) return <div style={styles.errorBanner}>{error}</div>;

  const maxTop = stats.topSellers.length ? stats.topSellers[0].qty : 1;

  return (
    <div style={styles.fadeIn}>
      <SectionTitle eyebrow="Today" title="Shop overview" />
      <div style={styles.statGrid}>
        <StatCard
          label="Today's revenue"
          value={currency(stats.todayRevenue)}
          accent="terracotta"
          sub={`${stats.todaySalesCount} sale${stats.todaySalesCount === 1 ? "" : "s"} today`}
        />
        <StatCard
          label="All-time revenue"
          value={currency(stats.allTimeRevenue)}
          accent="sage"
          sub={`${stats.totalUnitsSold} units sold total`}
        />
        <StatCard
          label="Inventory value"
          value={currency(stats.inventoryValue)}
          accent="mustard"
          sub={`${stats.productCount} products tracked`}
        />
        <StatCard
          label="Low stock items"
          value={stats.lowStock.length}
          accent={stats.lowStock.length > 0 ? "alert" : "sage"}
          sub={stats.lowStock.length > 0 ? "needs reordering" : "all stocked up"}
          onClick={() => navigate("/inventory")}
        />
      </div>

      <div style={{ ...styles.dashGrid, gridTemplateColumns: isNarrow ? "1fr" : "1.3fr 1fr" }}>
        <div style={styles.panel}>
          <div style={styles.panelTitle}>Top sellers</div>
          {stats.topSellers.length === 0 ? (
            <EmptyState text="No sales recorded yet. Ring up your first sale to see trends here." />
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 14 }}>
              {stats.topSellers.map((item) => (
                <div key={item.name}>
                  <div style={styles.barRow}>
                    <span style={styles.barLabel}>{item.name}</span>
                    <span style={styles.barQty}>{item.qty} sold</span>
                  </div>
                  <div style={styles.barTrack}>
                    <div style={{ ...styles.barFill, width: `${(item.qty / maxTop) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={styles.panel}>
          <div style={styles.panelTitle}>
            <AlertTriangle size={15} style={{ marginRight: 6, position: "relative", top: 2 }} />
            Reorder list
          </div>
          {stats.lowStock.length === 0 ? (
            <EmptyState text="Every product is above its reorder level. Nothing to restock." />
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 14 }}>
              {stats.lowStock.map((p) => (
                <div key={p.id} style={styles.reorderRow}>
                  <div>
                    <div style={styles.reorderName}>{p.name}</div>
                    <div style={styles.reorderMeta}>{p.sku} · reorder at {p.reorderLevel}</div>
                  </div>
                  <div style={styles.reorderStock}>{p.stock} left</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, sub, accent, onClick }) {
  return (
    <div style={{ ...styles.statCard, cursor: onClick ? "pointer" : "default" }} onClick={onClick}>
      <div style={{ ...styles.statAccent, background: ACCENTS[accent] }} />
      <div style={styles.statLabel}>{label}</div>
      <div style={styles.statValue}>{value}</div>
      <div style={styles.statSub}>{sub}</div>
    </div>
  );
}
