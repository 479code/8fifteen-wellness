import React, { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { useAuth } from "../lib/AuthContext";
import { api } from "../lib/api";
import { styles } from "../lib/styleTokens";
import { SectionTitle, EmptyState, useToast, Toast } from "../components/Shared";

export default function Staff() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const { toast, showToast } = useToast();

  const loadUsers = async () => {
    try {
      const data = await api.listUsers();
      setUsers(data.users);
    } catch (err) {
      setError(err.message || "Could not load staff list.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Remove this user's access? They won't be able to sign in anymore.")) return;
    try {
      await api.deleteUser(id);
      setUsers((prev) => prev.filter((u) => u.id !== id));
      showToast("User removed.");
    } catch (err) {
      showToast(err.message || "Could not remove user.");
    }
  };

  const handleAdd = async (payload) => {
    const data = await api.createUser(payload);
    setUsers((prev) => [data.user, ...prev]);
    showToast(`${payload.name} added.`);
    setShowForm(false);
  };

  if (loading) return <div style={styles.emptyState}>Loading staff…</div>;
  if (error) return <div style={styles.errorBanner}>{error}</div>;

  return (
    <div style={styles.fadeIn}>
      <SectionTitle
        eyebrow="Team"
        title="Staff accounts"
        action={
          <button style={styles.primaryBtn} onClick={() => setShowForm(true)}>
            <Plus size={16} /> Add account
          </button>
        }
      />

      <div style={styles.tableWrap}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Name</th>
              <th style={styles.th}>Email</th>
              <th style={styles.th}>Role</th>
              <th style={{ ...styles.th, textAlign: "right" }}></th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} style={styles.tr}>
                <td style={styles.td}>{u.name}{u.id === currentUser.id ? " (you)" : ""}</td>
                <td style={{ ...styles.td, color: "#8a7a64" }}>{u.email}</td>
                <td style={styles.td}><span style={styles.categoryTag}>{u.role}</span></td>
                <td style={{ ...styles.td, textAlign: "right" }}>
                  {u.id !== currentUser.id && (
                    <button style={styles.deleteBtn} onClick={() => handleDelete(u.id)}><Trash2 size={14} /></button>
                  )}
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr><td colSpan={4} style={{ padding: "32px 0" }}><EmptyState text="No staff accounts yet." /></td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && <AddUserModal onAdd={handleAdd} onClose={() => setShowForm(false)} />}
      <Toast toast={toast} />
    </div>
  );
}

function AddUserModal({ onAdd, onClose }) {
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "staff" });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await onAdd(form);
    } catch (err) {
      setError(err.message || "Could not create account.");
      setSubmitting(false);
    }
  };

  return (
    <div style={styles.modalOverlay} onClick={onClose}>
      <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div style={styles.modalHeader}><span style={styles.modalTitle}>Add staff account</span></div>
        {error && <div style={styles.errorBanner}>{error}</div>}
        <form onSubmit={handleSubmit} style={styles.form}>
          <label style={styles.label}>
            Full name
            <input style={styles.input} value={form.name} onChange={update("name")} required />
          </label>
          <label style={styles.label}>
            Email
            <input style={styles.input} type="email" value={form.email} onChange={update("email")} required />
          </label>
          <label style={styles.label}>
            Temporary password
            <input style={styles.input} type="text" value={form.password} onChange={update("password")} required minLength={6} />
          </label>
          <label style={styles.label}>
            Role
            <select style={styles.input} value={form.role} onChange={update("role")}>
              <option value="staff">Staff</option>
              <option value="admin">Admin</option>
            </select>
          </label>
          <button type="submit" style={{ ...styles.primaryBtn, ...(submitting ? styles.primaryBtnDisabled : {}) }} disabled={submitting}>
            {submitting ? "Creating…" : "Create account"}
          </button>
        </form>
      </div>
    </div>
  );
}
