import React, { useEffect, useState } from "react";
import { Plus, Minus, Search, Receipt, X } from "lucide-react";
import { api } from "../lib/api";
import { styles, currency } from "../lib/styleTokens";
import { SectionTitle, EmptyState, useToast, Toast, useIsNarrow } from "../components/Shared";

export default function RecordSale() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState("");
  const [checkingOut, setCheckingOut] = useState(false);
  const { toast, showToast } = useToast();
  const isNarrow = useIsNarrow();

  const loadProducts = async () => {
    try {
      const data = await api.listProducts();
      setProducts(data.products);
    } catch (err) {
      setError(err.message || "Could not load products.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const filtered = products.filter((p) => p.stock > 0 && p.name.toLowerCase().includes(query.toLowerCase()));

  const addToCart = (product) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) return prev;
        return prev.map((c) => (c.id === product.id ? { ...c, qty: c.qty + 1 } : c));
      }
      return [...prev, { id: product.id, name: product.name, price: product.price, qty: 1, maxStock: product.stock }];
    });
  };

  const changeQty = (id, delta) => {
    setCart((prev) =>
      prev.map((c) => (c.id === id ? { ...c, qty: Math.min(c.maxStock, Math.max(1, c.qty + delta)) } : c)).filter((c) => c.qty > 0)
    );
  };

  const removeFromCart = (id) => setCart((prev) => prev.filter((c) => c.id !== id));

  const total = cart.reduce((sum, c) => sum + c.price * c.qty, 0);

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setCheckingOut(true);
    try {
      const data = await api.recordSale({
        customerName: customer.trim() || "Walk-in",
        items: cart.map((c) => ({ productId: c.id, qty: c.qty })),
      });
      showToast(`Sale recorded — ${currency(data.sale.total)}`);
      setCart([]);
      setCustomer("");
      setQuery("");
      loadProducts();
    } catch (err) {
      showToast(err.message || "Could not record sale.");
      loadProducts();
    } finally {
      setCheckingOut(false);
    }
  };

  if (loading) return <div style={styles.emptyState}>Loading products…</div>;
  if (error) return <div style={styles.errorBanner}>{error}</div>;

  return (
    <div style={styles.fadeIn}>
      <SectionTitle eyebrow="Counter" title="Record a sale" />
      <div style={{ ...styles.saleGrid, gridTemplateColumns: isNarrow ? "1fr" : "1.4fr 1fr" }}>
        <div>
          <div style={styles.searchBox}>
            <Search size={16} color="#9c8c78" />
            <input
              style={styles.searchInput}
              placeholder="Search products to add…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div style={styles.productPickGrid}>
            {filtered.map((p) => (
              <button key={p.id} style={styles.pickCard} onClick={() => addToCart(p)}>
                <div style={styles.pickName}>{p.name}</div>
                <div style={styles.pickMeta}>
                  <span>{currency(p.price)}</span>
                  <span style={styles.pickStock}>{p.stock} in stock</span>
                </div>
              </button>
            ))}
            {filtered.length === 0 && <EmptyState text="No matching products in stock." />}
          </div>
        </div>

        <div style={{ ...styles.receipt, position: isNarrow ? "static" : "sticky" }}>
          <div style={styles.receiptHeader}><Receipt size={18} /><span>Current sale</span></div>
          <input
            style={styles.customerInput}
            placeholder="Customer name (optional)"
            value={customer}
            onChange={(e) => setCustomer(e.target.value)}
          />
          <div style={styles.receiptDivider} />
          {cart.length === 0 ? (
            <EmptyState text="Tap a product on the left to add it to this sale." />
          ) : (
            <div style={styles.receiptItems}>
              {cart.map((c) => (
                <div key={c.id} style={styles.receiptItem}>
                  <div style={{ flex: 1 }}>
                    <div style={styles.receiptItemName}>{c.name}</div>
                    <div style={styles.receiptItemPrice}>{currency(c.price)} each</div>
                  </div>
                  <div style={styles.stockControl}>
                    <button style={styles.stockBtn} onClick={() => changeQty(c.id, -1)}><Minus size={12} /></button>
                    <span style={styles.stockNum}>{c.qty}</span>
                    <button style={styles.stockBtn} onClick={() => changeQty(c.id, 1)}><Plus size={12} /></button>
                  </div>
                  <div style={styles.receiptLineTotal}>{currency(c.price * c.qty)}</div>
                  <button style={styles.iconBtnSmall} onClick={() => removeFromCart(c.id)}><X size={13} /></button>
                </div>
              ))}
            </div>
          )}
          <div style={styles.receiptDivider} />
          <div style={styles.receiptTotalRow}>
            <span>Total</span>
            <span style={styles.receiptTotal}>{currency(total)}</span>
          </div>
          <button
            style={{ ...styles.primaryBtn, width: "100%", justifyContent: "center", marginTop: 14, ...((cart.length === 0 || checkingOut) ? styles.primaryBtnDisabled : {}) }}
            onClick={handleCheckout}
            disabled={cart.length === 0 || checkingOut}
          >
            {checkingOut ? "Recording…" : "Complete sale"}
          </button>
        </div>
      </div>
      <Toast toast={toast} />
    </div>
  );
}
