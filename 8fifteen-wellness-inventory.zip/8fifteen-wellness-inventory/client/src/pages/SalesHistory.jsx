import React, { useEffect, useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import { api } from "../lib/api";
import { styles, currency } from "../lib/styleTokens";
import { SectionTitle, EmptyState } from "../components/Shared";

export default function SalesHistory() {
  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const data = await api.listSales({ limit: 200 });
        setSales(data.sales);
      } catch (err) {
        setError(err.message || "Could not load sales history.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const grouped = useMemo(() => {
    const map = {};
    sales.forEach((s) => {
      const day = s.createdAt.slice(0, 10);
      if (!map[day]) map[day] = [];
      map[day].push(s);
    });
    return Object.entries(map).sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [sales]);

  if (loading) return <div style={styles.emptyState}>Loading sales history…</div>;
  if (error) return <div style={styles.errorBanner}>{error}</div>;

  return (
    <div style={styles.fadeIn}>
      <SectionTitle eyebrow="Records" title="Sales history" />
      {sales.length === 0 ? (
        <EmptyState text="No sales yet. Completed sales will appear here, grouped by day." />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
          {grouped.map(([day, daySales]) => {
            const dayTotal = daySales.reduce((sum, s) => sum + s.total, 0);
            return (
              <div key={day}>
                <div style={styles.dayHeader}>
                  <span style={styles.dayLabel}>
                    {new Date(day + "T00:00:00").toLocaleDateString("en-NG", { weekday: "long", month: "short", day: "numeric" })}
                  </span>
                  <span style={styles.dayTotal}>{currency(dayTotal)}</span>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {daySales.map((s) => {
                    const isOpen = expanded === s.id;
                    return (
                      <div key={s.id} style={styles.saleCard}>
                        <button style={styles.saleCardHeader} onClick={() => setExpanded(isOpen ? null : s.id)}>
                          <div style={styles.saleCardLeft}>
                            <span style={styles.saleTime}>
                              {new Date(s.createdAt).toLocaleTimeString("en-NG", { hour: "2-digit", minute: "2-digit" })}
                            </span>
                            <span style={styles.saleCustomer}>{s.customerName}</span>
                            <span style={styles.saleItemCount}>{s.items.reduce((a, i) => a + i.qty, 0)} item(s)</span>
                          </div>
                          <div style={styles.saleCardRight}>
                            <span style={styles.saleTotal}>{currency(s.total)}</span>
                            <ChevronDown size={16} style={{ transform: isOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
                          </div>
                        </button>
                        {isOpen && (
                          <div style={styles.saleDetail}>
                            {s.items.map((it, idx) => (
                              <div key={idx} style={styles.saleDetailRow}>
                                <span>{it.name} × {it.qty}</span>
                                <span style={{ fontFamily: "var(--mono)" }}>{currency(it.unitPrice * it.qty)}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
