import React, { useEffect, useState } from "react";
import { Plus, Minus, Search, Trash2 } from "lucide-react";
import { useAuth } from "../lib/AuthContext";
import { api } from "../lib/api";
import { styles, currency } from "../lib/styleTokens";
import { SectionTitle, EmptyState, useToast, Toast } from "../components/Shared";

const CATEGORIES = ["All", "Beauty & Cosmetics", "Personal Care", "Tea", "General Retail"];

export default function Inventory() {
  const { isAdmin } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [showForm, setShowForm] = useState(false);
  const { toast, showToast } = useToast();

  const loadProducts = async () => {
    try {
      const data = await api.listProducts();
      setProducts(data.products);
    } catch (err) {
      setError(err.message || "Could not load inventory.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const handleAdjust = async (id, delta) => {
    // Optimistic update for snappy +/- buttons, reconciled with the server response.
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, stock: Math.max(0, p.stock + delta) } : p)));
    try {
      await api.adjustStock(id, delta, delta > 0 ? "Manual restock" : "Manual correction");
    } catch (err) {
      showToast(err.message || "Could not update stock.");
      loadProducts();
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Remove this product from inventory? This cannot be undone.")) return;
    try {
      await api.deleteProduct(id);
      setProducts((prev) => prev.filter((p) => p.id !== id));
      showToast("Product removed.");
    } catch (err) {
      showToast(err.message || "Could not delete product.");
    }
  };

  const handleAdd = async (payload) => {
    try {
      const data = await api.createProduct(payload);
      setProducts((prev) => [...prev, data.product].sort((a, b) => a.name.localeCompare(b.name)));
      showToast(`${payload.name} added to inventory.`);
      setShowForm(false);
    } catch (err) {
      throw err;
    }
  };

  const filtered = products.filter((p) => {
    const matchesCategory = category === "All" || p.category === category;
    const matchesQuery =
      p.name.toLowerCase().includes(query.toLowerCase()) || p.sku.toLowerCase().includes(query.toLowerCase());
    return matchesCategory && matchesQuery;
  });

  if (loading) return <div style={styles.emptyState}>Loading inventory…</div>;
  if (error) return <div style={styles.errorBanner}>{error}</div>;

  return (
    <div style={styles.fadeIn}>
      <SectionTitle eyebrow="Catalog" title="Inventory" />

      <div style={styles.toolbar}>
        <div style={styles.searchBox}>
          <Search size={16} color="#9c8c78" />
          <input
            style={styles.searchInput}
            placeholder="Search by name or SKU…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div style={styles.categoryChips}>
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              style={{ ...styles.chip, ...(category === c ? styles.chipActive : {}) }}
            >
              {c}
            </button>
          ))}
        </div>
        {isAdmin && (
          <button style={styles.primaryBtn} onClick={() => setShowForm(true)}>
            <Plus size={16} /> Add product
          </button>
        )}
      </div>

      <div style={styles.tableWrap}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Product</th>
              <th style={styles.th}>Category</th>
              <th style={styles.th}>SKU</th>
              <th style={{ ...styles.th, textAlign: "right" }}>Price</th>
              <th style={{ ...styles.th, textAlign: "center" }}>Stock</th>
              {isAdmin && <th style={{ ...styles.th, textAlign: "right" }}></th>}
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => {
              const low = p.stock <= p.reorderLevel;
              return (
                <tr key={p.id} style={styles.tr}>
                  <td style={styles.td}><div style={styles.productName}>{p.name}</div></td>
                  <td style={styles.td}><span style={styles.categoryTag}>{p.category}</span></td>
                  <td style={{ ...styles.td, fontFamily: "var(--mono)", color: "#9c8c78", fontSize: 12 }}>{p.sku}</td>
                  <td style={{ ...styles.td, textAlign: "right", fontFamily: "var(--mono)" }}>{currency(p.price)}</td>
                  <td style={{ ...styles.td, textAlign: "center" }}>
                    <div style={styles.stockControl}>
                      <button style={styles.stockBtn} onClick={() => handleAdjust(p.id, -1)}><Minus size={13} /></button>
                      <span style={{ ...styles.stockNum, color: low ? "#C1502E" : "#2B2118" }}>{p.stock}</span>
                      <button style={styles.stockBtn} onClick={() => handleAdjust(p.id, 1)}><Plus size={13} /></button>
                    </div>
                    {low && <div style={styles.lowTag}>low stock</div>}
                  </td>
                  {isAdmin && (
                    <td style={{ ...styles.td, textAlign: "right" }}>
                      <button style={styles.deleteBtn} onClick={() => handleDelete(p.id)}><Trash2 size={14} /></button>
                    </td>
                  )}
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr><td colSpan={6} style={{ padding: "32px 0" }}><EmptyState text="No products match your search." /></td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showForm && <AddProductModal onAdd={handleAdd} onClose={() => setShowForm(false)} />}
      <Toast toast={toast} />
    </div>
  );
}

function AddProductModal({ onAdd, onClose }) {
  const [form, setForm] = useState({
    name: "", category: "Beauty & Cosmetics", price: "", cost: "", stock: "", reorderLevel: "5", sku: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.price) return;
    setSubmitting(true);
    setError("");
    try {
      await onAdd({
        name: form.name,
        category: form.category,
        price: Number(form.price),
        cost: Number(form.cost) || 0,
        stock: Number(form.stock) || 0,
        reorderLevel: Number(form.reorderLevel) || 5,
        sku: form.sku || undefined,
      });
    } catch (err) {
      setError(err.message || "Could not add product.");
      setSubmitting(false);
    }
  };

  return (
    <div style={styles.modalOverlay} onClick={onClose}>
      <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div style={styles.modalHeader}>
          <span style={styles.modalTitle}>Add new product</span>
        </div>
        {error && <div style={styles.errorBanner}>{error}</div>}
        <form onSubmit={handleSubmit} style={styles.form}>
          <label style={styles.label}>
            Product name
            <input style={styles.input} value={form.name} onChange={update("name")} placeholder="e.g. Cast Iron Skillet 26cm" required />
          </label>
          <div style={styles.formRow}>
            <label style={styles.label}>
              Category
              <select style={styles.input} value={form.category} onChange={update("category")}>
                {CATEGORIES.filter((c) => c !== "All").map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>
            <label style={styles.label}>
              SKU (optional)
              <input style={styles.input} value={form.sku} onChange={update("sku")} placeholder="auto-generated" />
            </label>
          </div>
          <div style={styles.formRow}>
            <label style={styles.label}>
              Selling price (₦)
              <input style={styles.input} type="number" min="0" value={form.price} onChange={update("price")} required />
            </label>
            <label style={styles.label}>
              Cost price (₦)
              <input style={styles.input} type="number" min="0" value={form.cost} onChange={update("cost")} />
            </label>
          </div>
          <div style={styles.formRow}>
            <label style={styles.label}>
              Opening stock
              <input style={styles.input} type="number" min="0" value={form.stock} onChange={update("stock")} />
            </label>
            <label style={styles.label}>
              Reorder level
              <input style={styles.input} type="number" min="0" value={form.reorderLevel} onChange={update("reorderLevel")} />
            </label>
          </div>
          <button type="submit" style={{ ...styles.primaryBtn, ...(submitting ? styles.primaryBtnDisabled : {}) }} disabled={submitting}>
            {submitting ? "Adding…" : "Add to inventory"}
          </button>
        </form>
      </div>
    </div>
  );
}
